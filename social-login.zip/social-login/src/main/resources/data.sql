insert into Account (username, password, firstName, lastName) values ('habuma', 'tacos', 'Craig', 'Walls');
insert into Account (username, password, firstName, lastName) values ('rclarkson', 'atlanta', 'Roy', 'Clarkson');

